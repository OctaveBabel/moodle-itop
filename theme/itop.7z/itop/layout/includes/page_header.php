<header id="page-header" class="clearfix">
    <?php // echo $html->heading; ?>
    <div id="page-navbar" class="clearfix">
        <nav class="breadcrumb-nav"><?php echo $OUTPUT->navbar(); ?></nav>
        <div class="breadcrumb-button"><?php echo $OUTPUT->page_heading_button(); ?></div>
    </div>
    <div id="course-header">
        <?php echo $OUTPUT->course_header(); ?>
    </div>
</header>
